
<!--The CSS Used here is mainly for div and differs on different forms. All styling css has been deleted and vue classes are used-->
<style>
.overlap
{
    max-width: 150px;
    max-height: 150px;
    overflow: hidden;
}




#page-wraps {
   
    width: 100%;
  
    position: relative;
    

}

#left1 {
    
    width: 25%;
    height: auto;
   
    float: left;
    padding-right: 1%;
    
    
}

#left2 {
    width: 25%;
    height: auto;
    float: left;
   
    padding-right: 1%;
  
}
#left3 {
    width: 25%;
    height: auto;
    float: left;
   
    padding-right: 1%;
  
}
#left4 {
    width: 25%;
    height: auto;
    float: left;
   
    padding-right: 1%;
  
}

#page-wrap {
   
    width: 100%;
    margin: 40px auto;
    position: relative;
    

}

#left {
    
    width: 33%;
    height: auto;
   
    float: left;
    padding-right: 8%;
    
    
}

#mid {
    width: 33%;
    height: auto;
    float: left;
   
    padding-left: 8%;
  
}

#rightt {
    
    width: 34%;
    height: auto;
    float: left;
    padding-right: 2.5%;
    padding-left: 2.5%;
}

#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
  
}

#customers td, #customers th {
  border: 1px solid #ddd;
  
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}


.right {
  position: static;
  right: 0px;
  
  padding: 10px;
  
   width: 100%;
   min-width: 10px;  
   max-width: 300px;

}

  .tables 
{
    table-layout:fixed;
    width:100%;
    
}


#page-wraps {
   
    width: 100%;
  
    position: relative;
    

}

#left1 {
    
    width: 25%;
    height: auto;
   
    float: left;
    padding-right: 1%;
    
    
}

#left2 {
    width: 25%;
    height: auto;
    float: left;
   
    padding-right: 1%;
  
}
</style>
<style>
#tds_page-wrap {
   
    width: 100%;
  
    position: relative;
    

}

#tds_left {
    
    width: 50%;
    height: auto;
   
    float: left;
    padding-right: 10%;
    
    
}

#tds_right {
    width: 50%;
    height: auto;
    float: left;
    padding-bottom: 12%;
   
    padding-left: 10%;
  
}


#tds2_page-wrap {
   
    width: 100%;
    
    position: relative;
    height:auto;
    float: left;
    

}


#tds2_left {
    
    width: 30%;
    height: auto;
   
    float: left;
    padding-right: 1%;
    
    
}

#tds2_right {
    width: 70%;
    height: auto;
    float: left;
   
    padding-right: 1%;
  
}
td
{
    max-width: 150px;
    max-height: 150px;
    overflow: hidden;
}
#tds3_page-wrap {
   
     width: 100%;
    
    position: static;
    height:auto;
    float: right;
    
    
    

}
</style>
<template>

    <div class="vx-card p-6" style="" >
     <!--UPDATE START-->
      <table width="100%" border="0" class="tables">
     <tr>
      <td width="25%">
        
      </td>
       <td width="50%"><center><h1>Sale 1<br><h4><font color="blue">View</font></h4></h1></center></td>
       <td width="25%"  align="right">Today {{now}}<br/> {{currentday}}
    
                
              
        </td>
         
       


      </tr>
     
     
    
      </table>

         
    <!--UPDATE END-->
  
    <table border="0" width="100%" class="tables">
      
        <tr>
            <td width="65%" align="left">


              
                <div class="" align="left"  style="width: 100%; min-width: 10px; max-width: 400px; ">
         
         




                <table border="0" class="tables" align="left">
                <tr>
                <td class="overlap">
                Date 
                </td>
                <td>
                 
                    <div class="vx-col sm:w-1/6 w-full">
                    <flat-pickr  v-model="date" size="small" style="width:180px; height:25px;"  placeholder="choose Date" />
                    </div>

                </td>
                
                </tr>
                <tr>
                  <td>

        
                 
                <div class="vx-col sm:w-1/3 w-full overlap">
                    <span><p>B.No</p></span>
                </div>
                </td>
                <td>
                
                      <div class="vx-col sm:w-1/5">
                      <vs-input v-model="vno" size="small" style="width:180px; height:25px;" placeholder="" />
                    </div>
                
                </td>
                
                
                </tr>
                </table>
                </div>


            </td>
            
           
            <td width="35%"  align="right">
           
                
              <div align="right">
       <div class="right" align="right">
         <table>
           <tr>
             <td>
        <vs-button color="primary" icon-pack="feather" icon="icon-settings" /> 
        </td>
        <td>
        <vs-button color="primary" type="filled" icon-pack="feather" icon="icon-align-justify"></vs-button>
        </td>
        </tr>
        </table>
         </div>
        </div>
            </td>
        </tr>
        
    </table>


   
<br>

	<div id="page-wrap">

		<div id="left">
      <table border="0" width="100%" cellspacing="5" class="tables">
        <tr>
          <td class="overlap">Cust. Name</td>
          <td><vs-input class="w-full" size="small" v-model="input1" /></td>
        </tr>
        <tr>
          <td class="overlap">City</td>
          <td><vs-input class="w-full" size="small" v-model="input1" /></td>
        </tr>
        <tr>
          <td class="overlap">GST No.</td>
          <td><vs-input class="w-full" size="small" v-model="input1" /></td>
        </tr>
        <tr>
          <td class="overlap">PAN</td>
          <td><vs-input class="w-full" size="small" v-model="input1" /></td>
        </tr>
      </table>
    </div>
		
		<div id="rightt">
      <table border="0" width="100%" cellspacing="5" class="tables">
        <tr>
          <td class="overlap">GR. No</td>
          <td><vs-input class="w-full" size="small" v-model="input1" /></td>
        </tr>
        <tr>
          <td class="overlap">Terms</td>
          <td><vs-input class="w-full" size="small" v-model="input1" /></td>
        </tr>
        <tr>
          <td class="overlap">Vehicle</td>
          <td><vs-input class="w-full" size="small" v-model="input1" /></td>
        </tr>
        <tr>
          <td >
            
            <vs-checkbox v-model="checkBox1" ></vs-checkbox>
            
          </td>
          <td align="left">
            
            Late Payment Alert
            
            </td>
        </tr>
      </table>
    </div>
			
        <div id="mid">
          <table border="0" width="100%" cellspacing="5"  class="tables">
        <tr>
          <td class="overlap">Tax Type</td>
          <td>
             
             <vs-select v-model="city" class="w-full select-large" style="height:45px;">
          <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
 
 
        </vs-select>

       
          </td>
        </tr>
        <tr>
          <td class="overlap">Bill Cash</td>
          <td>

             <vs-select v-model="city" class="w-full select-large" style="height:45px;" > 
          <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
 
 
        </vs-select>
       
          </td>
        </tr>
        <tr>
          <td class="overlap">Mfg. Trd</td>
          <td>

             <vs-select v-model="city" class="w-full select-large" style="height:45px;">
          <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
 
 
        </vs-select>
          </td>
        </tr>
        
      </table>
        </div>
       
		<div style="clear:both;"></div>
	</div>



   <!--Table start here -->
<div  style="overflow-x:auto;">  
<table id="customers" >
  <tr >
    <th class="bg-primary">Product Name</th>
    <th class="bg-primary">Description</th>
    <th class="bg-primary">Pcs</th>
    <th class="bg-primary">Qty</th>
    <th class="bg-primary">Rate</th>
     <th class="bg-primary">Amount</th>

     <th class="bg-primary">Dis@</th>
     <th class="bg-primary">Discount</th>
     <th class="bg-primary">Tax@</th>
     <th class="bg-primary">C.Gst</th>
     <th class="bg-primary">S.Gst</th>
     <th class="bg-primary">I.Gst</th>
     <th class="bg-primary">Delete</th>
  </tr>
      <!--cashvouchars is a variables use for FOR LOOP, Vue.js function are used to perform action like add/delete row and sow notifications -->
      <!--Any Numeric Input validation and input will show right hand (dir="rtl"),(@keypress="onlyNumber") use for int val-->

<tr v-for="(cashVaucher, k) in cashVauchers" :key="k">  
    <td scope="row">
        <vs-input class="w-full" size="small" v-model="cashVaucher.prod_name" v-on:keyup.enter="addNewRowEnterkey(k,cashVaucher)" />
    </td>
    <td scope="row">
        <vs-input class="w-full" size="small" v-model="cashVaucher.desc" v-on:keyup.enter="addNewRowEnterkey(k,cashVaucher)" />
    </td>
    <td>
      <vs-input class="w-full" size="small"  v-model="cashVaucher.pcs" v-on:keyup.enter="addNewRowEnterkey(k,cashVaucher)" dir="rtl"  @keypress="onlyNumber" />
    </td>
     
    <td>
      <vs-input class="w-full" size="small"  v-model="cashVaucher.qty" v-on:keyup.enter="addNewRowEnterkey(k,cashVaucher)" dir="rtl"  @keypress="onlyNumber" />
    </td>

    <td>
      <vs-input class="w-full" size="small"  v-model="cashVaucher.rate" v-on:keyup.enter="addNewRowEnterkey(k,cashVaucher)" dir="rtl"  @keypress="onlyNumber" />
    </td>
     
    <td>
      <vs-input class="w-full" size="small"  v-model="cashVaucher.amount" v-on:keyup.enter="addNewRowEnterkey(k,cashVaucher)" dir="rtl"  @keypress="onlyNumber" />
    </td>
     
    <td>
      <vs-input class="w-full" size="small"  v-model="cashVaucher.dis_p" v-on:keyup.enter="addNewRowEnterkey(k,cashVaucher)" dir="rtl"  @keypress="onlyNumber" />
    </td>

    <td>
      <vs-input class="w-full" size="small"  v-model="cashVaucher.discount" v-on:keyup.enter="addNewRowEnterkey(k,cashVaucher)" dir="rtl"  @keypress="onlyNumber" />
    </td>
     
    <td>
      <vs-input class="w-full" size="small"  v-model="cashVaucher.tax_p" v-on:keyup.enter="addNewRowEnterkey(k,cashVaucher)" dir="rtl"  @keypress="onlyNumber" />
    </td>
     
    <td>
      <vs-input class="w-full" size="small"  v-model="cashVaucher.c_gst" v-on:keyup.enter="addNewRowEnterkey(k,cashVaucher)" dir="rtl"  @keypress="onlyNumber" />
    </td>
     
    <td>
      <vs-input class="w-full" size="small"  v-model="cashVaucher.s_gst" v-on:keyup.enter="addNewRowEnterkey(k,cashVaucher)" dir="rtl"  @keypress="onlyNumber" />
    </td>
     
    <td>
      <vs-input class="w-full" size="small"  v-model="cashVaucher.i_gst" v-on:keyup.enter="addNewRowEnterkey(k,cashVaucher)" dir="rtl"  @keypress="onlyNumber" />
    </td>
    
     <td align="center"><vs-button size="small" icon-pack="feather" icon="icon-trash" color="danger" style="margin:3px;"  @click="deleteRow(k, cashVaucher)"></vs-button></td>
  </tr>
  </table>
</div>

<!--Table end here -->



  <br/>
    <div id="example">
      <vs-button class="button" size="small" @click="addNewRow();addNotify()" ><i class="fa fa-plus"></i></vs-button>
     &nbsp;
      <vs-button class="button" size="small"  @click="pop"><i class="fa fa-minus"></i></vs-button>
          &nbsp;
        <vs-button class="button" size="small" @click="saveInvoice">show all data</vs-button>
    </div> <i class="far fa-trash-alt" @click="deleteRow(k, cashVaucher)"></i>
<br/>



    <div id="tds_page-wrap">
    <div id="tds_left">

    <table border="0"  cellspacing="5" class="tables">
      <tr>
        <td class="overlap">Shipped</td>
        <td><vs-input class="w-full" size="small" v-model="input1" /></td>
      </tr>
      <tr>
        <td class="overlap">Broker</td>
        <td><vs-input class="w-full" size="small" v-model="input1" /></td>
      </tr>
      <tr>
        <td class="overlap">Remarks</td>
        <td><vs-input class="w-full" size="small" v-model="input1" /></td>
      </tr>
      <tr>
        <td class="overlap">Transport</td>
        <td><vs-input class="w-full" size="small" v-model="input1" /></td>
      </tr>
      <tr>
        <td class="overlap">Adjust Advance Rs.</td>
        <td><vs-input class="w-full" size="small" v-model="input1" /></td>
      </tr>
      <tr>
        <td class="overlap">Date</td>
        <td>
          
            <div class="vx-col sm:w-1/6 w-full">
                    <flat-pickr  v-model="date" size="small" style="width:120px; height:25px;"  placeholder="choose Date" />
                    </div>


        </td>
      </tr>
    </table>
    </div>
    <div id="tds_right">
      <table border="0" cellspacing="5"  class="tables" >
      <tr>
        <td class="overlap">Value</td>
        <td><vs-input class="w-full" size="small" v-model="input1" /></td>
      </tr>
      <tr>
        <td class="overlap">Expenses</td>
        <td><vs-input class="w-full" size="small" v-model="input1" /></td>
      </tr>
      <tr>
        <td class="overlap">Taxes</td>
        <td><vs-input class="w-full" size="small" v-model="input1" /></td>
      </tr>
      <tr>
        <td class="overlap">Expenses</td>
        <td><vs-input class="w-full" size="small" v-model="input1" /></td>
      </tr>
      <tr>
        <td class="overlap">G. Total</td>
        <td><vs-input class="w-full" size="small" v-model="input1" /></td>
      </tr>
     
    </table>
    </div>
    </div>

      <div align="right" style="padding-top: 170px">
        <br>

      <div class="right" align="right">
        <br>
        
        <vs-button  color="primary" type="filled">Print</vs-button>
        &nbsp;
        <vs-button  color="primary" type="filled" style="!">Submit</vs-button>
        

      </div>
      </div>
      
      
      
    </div>

    
</template>

<script>
import  flatPickr  from 'vue-flatpickr-component';
import  'flatpickr/dist/flatpickr.css';
export default {
  data() {
        return {
            date:null,
            totalcount:0,
            cashVauchers: [{
            prod_name: '',
            desc: '',
            pcs: '',
            qty: '',
            rate: '',
            amount: '',
            dis_p: '',
            discount: '',
            tax_p: '',
            c_gst: '',
            s_gst: '',
            i_gst: '',
    
            }]
        } 
    },
    components:{
      flatPickr
    },
    methods:{
          addNewRow(){
              this.cashVauchers.push({
                prod_name: '',
                desc: '',
                pcs: '',
                qty: '',
                rate: '',
                amount: '',
                dis_p: '',
                discount: '',
                tax_p: '',
                c_gst: '',
                s_gst: '',
                i_gst: '',
    
            
            });
          },
         addNewRowEnterkey(index, cashVaucher) {
               var idx = this.cashVauchers.indexOf(cashVaucher);
                 var len = this.cashVauchers.length;
            console.log(idx,index);
            if (len-1==index) {
                this.cashVauchers.push({
                prod_name: '',
                desc: '',
                pcs: '',
                qty: '',
                rate: '',
                amount: '',
                dis_p: '',
                discount: '',
                tax_p: '',
                c_gst: '',
                s_gst: '',
                i_gst: '',
    

                });
                     this.addNotify();
            }
        },
        deleteNotify(){
            this.$vs.notify({
              text: 'Row is deleted',
              color: "danger",
              iconPack: 'feather',
              icon:'icon-trash'
             })
      },
       addNotify(){
            this.$vs.notify({
              text: 'Row is Added',
              color: "primary",
              iconPack: 'feather',
              icon:'icon-plus'
             })
      },
        deleteRow(index, cashVaucher) {
            var idx = this.cashVauchers.indexOf(cashVaucher);
            console.log(idx, index);
            if (idx > -1) {
                this.cashVauchers.splice(idx, 1);
            }
            this.deleteNotify();
        },
        pop(){
           this.cashVauchers.pop({
                prod_name: '',
                desc: '',
                pcs: '',
                qty: '',
                rate: '',
                amount: '',
                dis_p: '',
                discount: '',
                tax_p: '',
                c_gst: '',
                s_gst: '',
                i_gst: '',
        

            });
            this.deleteNotify();
        },
         saveInvoice() {
            alert(JSON.stringify(this.cashVauchers));
        },
        totaladd(cashVaucher){
             var total = parseFloat(cashVaucher.payment) * parseFloat(cashVaucher.discount);
           this.totalcount=total;
            this.calculateTotal(); 
        },  
          deletec(){
              this.cashVauchers.pop({
                
                prod_name: '',
                desc: '',
                pcs: '',
                qty: '',
                rate: '',
                amount: '',
                dis_p: '',
                discount: '',
                tax_p: '',
                c_gst: '',
                s_gst: '',
                i_gst: '',
        

            });
          },
         onlyNumber($event) {    
                let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
                if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) { // 46 is dot
                  return   $event.preventDefault();
                }
                else return null;           
          }
    },
    created() {
      for(var i=0;i<4;i++){
         this.addNewRow();
      }
    },
    computed: {
        now: function () {  
          var today = new Date();
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
          return date;
        },
        currentday: function(){
           var today = new Date();
           var weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var  currenday = weekday[today.getDay()];
            return currenday;
        }
    }
}
</script>




