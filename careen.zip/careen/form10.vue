/* eslint-disable vue/valid-template-root */
<style>
.overlap
{
    max-width: 150px;
    max-height: 150px;
    overflow: hidden;
    padding:10px
}
#page-wraps { 
    width: 100%;
    position: relative;
}
#lefts {  
    width: 50%;
    height: auto; 
    float: left;
    padding-right: 9%; 
}
#rights {
    width: 50%;
    height: auto;
    float: left; 
    padding-left: 9%;
}
#page-wrap {
    width: 100%;
    margin: 40px auto;
    position: relative;
}
#left {  
    width: 10%;
    height: auto; 
    float: left;
    padding-right: 8%;   
}
#mid {
    width: 45%;
    height: auto;
    float: left; 
    padding-left: 8%;
}
#rightt {  
    width: 45%;
    height: auto;
    float: left;
    padding-right: 2.5%;
    padding-left: 2.5%;
}
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
#customers td, #customers th {
  border: 1px solid #ddd;  
}
#customers tr:nth-child(even){background-color: #f2f2f2;}
#customers tr:hover {background-color: #ddd;}
#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}
.right {
  position: static;
  right: 0px;
  padding: 10px;
   width: 100%;
   min-width: 10px;  
   max-width: 300px;
}
@media screen and (min-width: 601px) {
  div.example {
    font-size: 15px;
    background-color:white; 
    padding: 55px;
    
    border-color: #7367f0;
     border-top-style: solid;
     border-bottom-style: solid;
  }
}

@media screen and (max-width: 600px) {
  div.example {
    font-size: 10px;
    background-color:white; 
    padding: 10px;
    
    border-color: #7367f0;
    border-top-style: solid;
    border-bottom-style: solid;
  }
  
}

.btns {
   width: 100%;
   min-width: 10px;  
   max-width: 300px; 
}
</style>
<style type="text/css">
  #middlecol {
   
    width: 100%;
    
  
  }

 
  .tables 
{
    table-layout:fixed;
    width:100%;
    
}

.users {
  table-layout: fixed;
  white-space: nowrap;
}
.users td {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* Column widths are based on these cells */
.rowid {
  width: 4%;
}
</style>
<template>

    <div class="vx-card p-6" style="" >
     <!--UPDATE START-->
      <table width="100%" border="0" class="tables">
         <tr>
           
            <td width="10%">   
            </td>
            <td width="50%"><center><h1><font color="#7367f0">TDS Form 26<br></font></h1></center></td>
            <td width="20%"  align="right">
       
          </td>
          </tr>
</table>
<br>
<table width="100%" border="0" class="tables"  align="center">
<tr>
    <td></td>
<td class="overlap"  width="33%" id="div.example"> 
    <vs-radio class="w-full" v-align="right"  size="small" v-model="radio1" vs-value="luis">Purchase Voucher</vs-radio>
</td>
<td class="overlap"   width="33%"> 
    <vs-radio class="w-full"  size="small" v-model="radio2" vs-value="luis">TDS Voucher</vs-radio>
</td>
<td class="overlap"   width="33%"> 
    <vs-radio class="w-full"  size="small" v-model="radio3" vs-value="luis">All</vs-radio>
</td>
</tr>
</table>
<br>
<table width="100%" border="0" class="tables"  align="center">
<tr>
        <td id="overlap">Type</td>
        <td class="overlap"> 
            <vs-select v-model="Values" class="w-full  sm:w-1/16" style="width:90px" >
                  <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
            </vs-select>
        </td>
</tr>
<br>
<tr>
        <td id="overlap">
            Issue Date 
            </td>
        <td id="overlap">
          <flat-pickr   v-model="date" size="small" style="width:195px;"  placeholder="choose Date" />
        </td>
        <td width="30%" id="overlap" align="center">
            TDS@
        </td>
        <td id="overlap">
            <vs-input  class="w-full"  size="small" v-model="input1"/>
        </td>
        <td></td>
    </tr><br>
    <tr>
        <td id="overlap" >
            BSR Code
        </td>
        <td id="overlap">
            <vs-input class="w-full" size="small" v-model="input2" />
        </td>
    </tr><br>
    <tr>
        <td id="overlap">
            Bank Name
        </td>
        <td id="overlap">
            <vs-input class="w-full" size="small" v-model="input3" />
        </td>
    </tr><br>
    <tr>
        <td id="overlap">
            Period From
        </td>
        <td id="overlap">
          <flat-pickr   v-model="date" size="small" style="width:195px;"  placeholder="choose Date" />
        </td>
        <td width="30%" id="overlap" align="center">
            To
        </td>
        <td id="overlap">
          <flat-pickr   v-model="date" size="small" style="width:195px;"  placeholder="choose Date" />
        </td>
    </tr>
</table><br>
<br>
<table width="100%" border="0" class="tables"  >
    <tr>
    <td></td>
        <td class="overlap"  width="33%"> 
            <vs-radio class="w-full" v-align="right"  size="small" v-model="radio1" vs-value="luis">Purchase Voucher</vs-radio>
        </td>
        <td class="overlap"   width="33%"> 
            <vs-radio class="w-full"  size="small" v-model="radio2" vs-value="luis">TDS Voucher</vs-radio>
        </td>
        <td class="overlap"   width="33%"> 
            <vs-radio class="w-full"  size="small" v-model="radio3" vs-value="luis">All</vs-radio>
        </td>
    </tr>
</table>
        <div >
        <div >
        <br>&nbsp;&nbsp;&nbsp;&nbsp;
                <center><vs-button  color="primary" type="filled">Edit</vs-button>&nbsp;
                <vs-button  color="primary" type="filled" style="!">Export</vs-button>&nbsp;
                <vs-button  color="primary" type="filled" style="!">Print</vs-button>&nbsp;
                </center>
      </div>
      </div>

</div>
</template>
<script>
import  flatPickr  from 'vue-flatpickr-component';
import  'flatpickr/dist/flatpickr.css';
export default {
  data() {
        return {
            date:null,
            input1:'',
            input2:'',
            input3:'',
            
        } 
    },
    components:{
      flatPickr
    },
    computed: {
        now: function () {  
          var today = new Date();
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
          return date;
        },
        currentday: function(){
           var today = new Date();
           var weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var  currenday = weekday[today.getDay()];
            return currenday;
        }
    }
}
</script>





















