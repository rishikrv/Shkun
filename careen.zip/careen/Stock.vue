<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;  
}
 #customers th {
  border: 1px solid #ddd; 
}
#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}

 .tables 
{
    table-layout:fixed;
    width:100%;
    
}



@media screen and (min-width: 601px) {
  div.example {
    font-size: 15px;
    background-color:white; 
    padding: 55px;
    
    border-color: #7367f0;
     border-top-style: solid;
     border-bottom-style: solid;
  }
}

@media screen and (max-width: 600px) {
  div.example {
    font-size: 10px;
    background-color:white; 
    padding: 10px;
    
    border-color: #7367f0;
    border-top-style: solid;
    border-bottom-style: solid;
  }
  
}

</style>
<template >

     <div class="vx-card p-6" style="" >
    
     <!--UPDATE START-->
      <table width="100%" border="0" class="tables">
     <tr>
      <td width="25%">
        
      </td>
       <td width="50%"><center><h1 class="text-primary">Stock Summary<br><h4><font color="grey">View</font></h4></h1></center></td>
       <td width="25%"  align="right">  
          <div align="right">
      <div class="right" align="center">
       <vs-button color="primary" icon-pack="feather" icon="icon-flag" />

      </div>
      </div>
      </td>
      </tr>
      </table>
    <!--UPDATE END-->
    <br>
  <div  class="tables" >
        <tr>
            <td  align="left">
                <table border="0" align="100%">
                <tr>
                <td width="15%">
                  From Date
                </td>
                <td class="overlap" > 
                  <flat-pickr  v-model="date" size="small" style="width:170px; height:25px;"  placeholder="choose Date" />
                </td>
                <td>
                <vs-checkbox  size="small" v-model="checkBox1"/>
                </td>
                <td  class="overlap" >
                    HSN
                </td>
                <td class="overlap" align="center" width="20%" >
                    Group
                </td>
                <td class="overlap" > 
                 <vs-input class="w-full"  size="small" v-model="input1"/>
                </td>
                <td  id="overlap" width="10%" align="center">
                    Filter
                </td>
                <td>
                    <vs-select v-model="filter" class="w-full  sm:w-1/10" style="width:30px" >
                    <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
                    </vs-select>
                </td> 
                </tr>
                <tr>
                <td>
                    Upto Date
                </td>
                 <td class="overlap"> 
                  <flat-pickr  v-model="date" size="small" style="width:170px; height:25px;"  placeholder="choose Date" />
                </td>
                <td>
                </td>
                <td>
                </td>
                <td id="overlap" align="center" width="20%">
                    Calculation
                </td>
                <td class="vx-col sm:w-1/6">
                        <vs-select v-model="cal" class="w-full select-large" >
                        <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
                        </vs-select>
                </td> 
                <td id="overlap" align="center">
                    Order By
                </td>
                <td >
                        <vs-select v-model="order" class="w-full select-large" >
                        <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
                        </vs-select>
                </td> 
                </tr>
                </table>
            </td>
        </tr>
    </div>
<br>
<table border="0" width="100%" >
        <tr>
            <td width="10%" class="overlap">
               <div class="vx-row mb-3">
                <div class="vx-col sm:w-1/10 " >
                <span> Method</span>
                </div>
               </div>
              </td>
                <td style="padding-left:35px"><div class="vx-col sm:w-1/5" >
                  <vs-select v-model="Values" class="w-full select-large" >
                  <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
                  </vs-select>
                </div></td> 
            
        </tr>
</table>
<br>
<div  style="overflow-x:auto;">  
<table id="customers" >
  <tr >

    <th class="bg-primary">Account Name</th>
    <th class="bg-primary">Opening</th>
     <th class="bg-primary">Receipt</th>
     <th class="bg-primary">Issue</th>
    <th class="bg-primary">Closing</th>
    <th class="bg-primary">Rate</th>
    <th class="bg-primary">Value</th>
      <th class="bg-primary">Discount</th>
    <th class="bg-primary">Delete</th>
  </tr>
  <tr v-for="(stock, k) in stk" :key="k">  
    <td><vs-input class="w-full" size="small" v-model="stock.accountname"  @change="totaladd(stock)"  v-on:keyup.enter="addNewRowEnterkey(k,stock)"/></td>
    <td><vs-input class="w-full" size="small" v-model="stock.opening" @change="totaladd(stock)" dir="rtl" @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,stock)"/></td>
    <td><vs-input class="w-full" size="small" v-model="stock.receipt"  dir="rtl"  v-on:keyup.enter="addNewRowEnterkey(k,stock)"/></td>
    <td><vs-input class="w-full" size="small" v-model="stock.issue" dir="rtl" @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,stock)"/></td>
    <td><vs-input class="w-full" size="small" v-model="stock.closing"  dir="rtl" @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,stock)"/></td>
    <td><vs-input class="w-full" size="small" v-model="stock.rate"  dir="rtl" @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,stock)"/></td>
    <td><vs-input class="w-full" size="small" v-model="stock.value"  dir="rtl" @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,stock)"/></td>
    <td><vs-input class="w-full" size="small" v-model="stock.discount"  dir="rtl" @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,stock)"/></td>
    <td align="center"><vs-button size="small" icon-pack="feather" icon="icon-trash" color="danger" style="margin:3px;"  @click="deleteRow(k, stock)"></vs-button></td>
  </tr>
  </table>
</div>
<br/>
<div id="example">
      <vs-button class="button" size="small" @click="addNewRow();addNotify()" ><i class="fa fa-plus"></i></vs-button>
     &nbsp;
      <vs-button class="button" size="small"  @click="pop"><i class="fa fa-minus"></i></vs-button>
          &nbsp;
        <vs-button class="button" size="small" @click="saveInvoice">show all data</vs-button>
    </div> <i class="far fa-trash-alt" @click="deleteRow(k, stock)"></i>
<br/>
<br>
<table border="0" width="100%" >
  <tr>
    <td align="right"> 
      Search
    </td>
    <td align>
      <vs-input class="w-full" size="small" v-model="input2" />
    </td>
    <td width="5%" >
      <vs-checkbox  size="small" v-model="checkBox2"/>
    </td>
    <td class="overlap"><font color="red">
      Filter Selected Item
    </font></td>
  </tr>
  <tr>
    <td width="20%" align="right">
      A/c Code
    </td>
    <td align>
      <vs-input class="w-full" size="small" v-model="input3" />
    </td>
    <td width="5%" >
     <vs-checkbox  size="small" v-model="checkBox3"/>
    </td>
    <td class="overlap" ><font color="red">
      Negative Stock Status
    </font></td>
      <td  align="center" class="mid" >
        <div id="example" width="70%" >
          <vs-button color="primary" icon-pack="feather" icon="icon-edit" />
      </div>
    </td>
    <td  align="center">
      <div id="example">
          <vs-button color="primary" icon-pack="feather" icon="icon-printer" />
      </div>
    </td>
    <td  align="center" width="10%">
      <div id="example">
      <vs-button color="primary" icon-pack="feather" icon="icon-save" />
      </div>
    </td>
  </tr>
  <tr>
    <td align="right">
    Filter
    </td>
    <td align="center">
      <vs-input class="w-full" size="small" v-model="input3" />
    </td>
    <td width="1%" >
      <vs-checkbox  size="small" v-model="checkBox4"/>    </td>
    <td class="overlap">
      Filter Selected Item
    </td>
    <td>
    </td>
    <td>
    </td>

  </tr>   
</table>
</div>    
</template>
<script>
import  flatPickr  from 'vue-flatpickr-component';
import  'flatpickr/dist/flatpickr.css';
export default {
  data() {
        return {
            date:null,
            totalcount:0,
            input1:'',
            input2:'',
            input3:'',
            stk: [{
            accountname:'',
            opening:'',
            receipt:'',
            issue: '',
            closing: '',
            rate: '',
            value: '',
            discount: '',
          
            }]
        } 
    },
    components:{
      flatPickr
    },
    methods:{
          addNewRow(){
              this.stk.push({
              tick:'',
              date:'',
              invno:'',
              accountname:'',
              accountname:'',
              opening:'',
              receipt:'',
              issue: '',
              closing: '',
              rate: '',
              value: '',
              discount: '',
              });
          },
         addNewRowEnterkey(index, bankVoucher) {
               var idx = this.stk.indexOf(bankVoucher);
                 var len = this.stk.length;
            console.log(idx,index);
            if (len-1==index) {
                this.stk.push({
                tick:'',
                date:'',
                invno:'',
                accountname:'',
                opening:'',
                receipt:'',
                issue: '',
                closing: '',
                rate: '',
                value: '',
                discount: '',
                });
                     this.addNotify();
            }
        },
        deleteNotify(){
            this.$vs.notify({
              text: 'Row is deleted',
              color: "danger",
              iconPack: 'feather',
              icon:'icon-trash'
             })
      },
       addNotify(){
            this.$vs.notify({
              text: 'Row is Added',
              color: "primary",
              iconPack: 'feather',
              icon:'icon-plus'
             })
      },
        deleteRow(index, bankVoucher) {
            var idx = this.stk.indexOf(bankVoucher);
            console.log(idx, index);
            if (idx > -1) {
                this.stk.splice(idx, 1);
            }
            this.deleteNotify();
        },
        pop(){
           this.stk.pop({         
            tick:'',
            date:'',
            invno:'',
            accountname:'',
            opening:'',
            receipt:'',
            issue: '',
            closing: '',
            rate: '',
            value: '',
            discount: '',
            });
            this.deleteNotify();
        },
         saveInvoice() {
            alert(JSON.stringify(this.stk));
        },
        totaladd(bankVoucher){
             var total = parseFloat(bankVoucher.payment) * parseFloat(bankVoucher.discount);
           this.totalcount=total;
            this.calculateTotal(); 
        },  
          deletec(){
              this.stk.pop({       
              tick:'',
              date:'',
              invno:'',
              accountname:'',
              opening:'',
              receipt:'',
              issue: '',
              closing: '',
              rate: '',
              value: '',
              discount: '',
            });
          },
         onlyNumber($event) {    
                let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
                if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) { // 46 is dot
                  return   $event.preventDefault();
                }
                else return null;           
          }
    },
    created() {
      for(var i=0;i<4;i++){
         this.addNewRow();
      }
    },
    computed: {
        now: function () {  
          var today = new Date();
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
          return date;
        },
        currentday: function(){
           var today = new Date();
           var weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var  currenday = weekday[today.getDay()];
            return currenday;
        }
    }
}
</script>