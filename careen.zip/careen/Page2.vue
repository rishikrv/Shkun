<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;  
}
 #customers th {
  border: 1px solid #ddd; 
}
#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}
</style>

     <!--Mini CSS used , {{now}}, {{currentday}} variable is used to get current date-->

<template>

    <div class="vx-card p-6" style="" >
     <!--UPDATE START-->
      <table width="100%" border="0" class="tables">
     <tr>
      <td width="25%">  
      </td>
       <td width="50%"><center><h1 class="text-primary">Production Card<br/><h4><font color="grey">View</font></h4></h1></center></td>
       <td width="25%"  align="right">Today {{now}}<br/> {{currentday}}            
        </td>
      </tr>
        <br/>
      </table>      
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6 " >
          <span> Voucher Dt </span>
        </div>
            <!--Used for date picking -->
        <div class="vx-col sm:w-1/6 w-full">
           <flat-pickr  v-model="date" size="small" style="width:180px; height:25px;"  placeholder="choose Date" />
        </div>
        <div></div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6 " >
          <span>Voucher No</span>
        </div>
        <div class="vx-col sm:w-1/5">
           <vs-input v-model="input1" size="small" style="width:180px; height:24px;" placeholder="" />
        </div>
      </div>
      <div></div>
  
<br/>
      
        <div class="vx-row mb-3" style="width:100%%; ">
          
        <div class="vx-col sm:w-1/6 " style="width:100%%; " >
          <span>Unit No</span>
        </div>
        <div class="vx-col sm:w-1/5">
           <vs-input v-model="input2" size="small" style="width:180px; height:30px;" placeholder="" />
        </div>
        
           <div class="vx-row mb-3">
                <div class="vx-col sm:w-1/6 " >
                  <span></span>
                </div>
                <div class="vx-col sm:w-1/10" >
                  <vs-select v-model="city" class="w-full select-large" style="width:180px; height:30px;" >
                  <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
                  </vs-select>
                </div> 
                </div>
      </div>

   <!--Table start here -->
<div  style="overflow-x:auto;">  
<table id="customers" >
  <tr >
    <th class="bg-primary">Stock Item Name.1</th>
    <th class="bg-primary">Narration</th>
    <th class="bg-primary">Issue</th>
    <th class="bg-primary">Receipt</th>
    <th class="bg-primary">Delete</th>
    
  </tr>
      <!--cashvouchars is a variables use for FOR LOOP, Vue.js function are used to perform action like add/delete row and sow notifications -->
      <!--Any Numeric Input validation and input will show right hand (dir="rtl"),(@keypress="onlyNumber") use for int val-->

<tr v-for="(pro, k) in prodt" :key="k">  
    <td scope="row">
        <vs-input class="w-full" size="small" v-model="pro.stock" v-on:keyup.enter="addNewRowEnterkey(k,pro)" />
    </td>
    <td>
      <vs-input class="w-full" size="small"  v-model="pro.narration" v-on:keyup.enter="addNewRowEnterkey(k,pro)" />
    </td>
    <td>
      <vs-input class="w-full"  size="small" v-model="pro.issue" @change="totaladd(pro)" dir="rtl"  @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,pro)"/>
    </td>
    <td><vs-input class="w-full" size="small" v-model="pro.receipt" v-on:keyup.enter="addNewRowEnterkey(k,pro)"/></td>
     <td align="center"><vs-button size="small" icon-pack="feather" icon="icon-trash" color="danger" style="margin:3px;"  @click="deleteRow(k, pro)"></vs-button></td>
  </tr>
  </table>
</div>
  <br/>
    <div id="example">
      <vs-button class="button" size="small" @click="addNewRow();addNotify()" ><i class="fa fa-plus"></i></vs-button>
     &nbsp;
      <vs-button class="button" size="small"  @click="pop"><i class="fa fa-minus"></i></vs-button>
          &nbsp;
        <vs-button class="button" size="small" @click="saveInvoice">show all data</vs-button>
    </div> <i class="far fa-trash-alt" @click="deleteRow(k, pro)"></i>
<br/>
      <br>
      <div id="right">
      <table border="0" width="100%" class="tables">
      <tr>
        <td align="right">Balance Qty</td>
        <td><vs-input class="w-full" size="small" v-model="totalcount" /></td>
        <td><vs-input class="w-full" size="small" v-model="input3" /></td>
        <td><vs-input class="w-full" size="small" v-model="input4" /></td>
  </tr>
</table>

    </div> 
    <div align="right" style="padding-top: 10px">
        <br>
      <div class="right" align="right">
        <br>
         <vs-button class="button"  @click="print">Print</vs-button>
        &nbsp;
         <vs-button class="button"  @click="submit">Submit</vs-button>

      </div>
    </div>      
  </div>
</template>

 <!--Script Start here all the action like @click and all method written above are define in this script, please useunique key value -->

<script>
import  flatPickr  from 'vue-flatpickr-component';
import  'flatpickr/dist/flatpickr.css';
export default {
  data() {
        return {
            date:null,
            totalcount:0,
            input1:'',
            input2:'',
            input3:'',
            input4:'',
            prodt: [{
            stock: '',
            narration: '',
            issue: '',
            receipt: '',
            }]
        } 
    },
    components:{
      flatPickr
    },
    methods:{
          addNewRow(){
              this.prodt.push({
                stock: '',
                narration: '',
                issue: '',
                receipt: '',
                });
          },
         addNewRowEnterkey(index, cashVaucher) {
               var idx = this.prodt.indexOf(cashVaucher);
                 var len = this.prodt.length;
            console.log(idx,index);
            if (len-1==index) {
                this.prodt.push({
                stock: '',
                narration: '',
                issue: '',
                receipt: '',
                });
                     this.addNotify();
            }
        },
        deleteNotify(){
            this.$vs.notify({
              text: 'Row is deleted',
              color: "danger",
              iconPack: 'feather',
              icon:'icon-trash'
             })
      },
       addNotify(){
            this.$vs.notify({
              text: 'Row is Added',
              color: "primary",
              iconPack: 'feather',
              icon:'icon-plus'
             })
      },
        deleteRow(index, cashVaucher) {
            var idx = this.prodt.indexOf(cashVaucher);
            console.log(idx, index);
            if (idx > -1) {
                this.prodt.splice(idx, 1);
            }
            this.deleteNotify();
        },
        pop(){
           this.prodt.pop({
                stock: '',
                narration: '',
                issue: '',
                receipt: '',
            });
            this.deleteNotify();
        },
         saveInvoice() {
            alert(JSON.stringify(this.prodt));
        },
        totaladd(cashVaucher){
             var total = parseFloat(cashVaucher.payment) * parseFloat(cashVaucher.discount);
           this.totalcount=total;
            this.calculateTotal(); 
        },  
          deletec(){
              this.prodt.pop({
                stock: '',
                narration: '',
                issue: '',
                receipt: '',
            });
          },
         onlyNumber($event) {    
                let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
                if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) { // 46 is dot
                  return   $event.preventDefault();
                }
                else return null;           
          }
    },
    created() {
      for(var i=0;i<4;i++){
         this.addNewRow();
      }
    },
    computed: {
        now: function () {  
          var today = new Date();
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
          return date;
        },
        currentday: function(){
           var today = new Date();
           var weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var  currenday = weekday[today.getDay()];
            return currenday;
        }
    }
}
</script>