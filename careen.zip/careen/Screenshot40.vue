<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;  
}
 #customers th {
  border: 1px solid #ddd; 
}
#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}
</style>

<template >

     <div class="vx-card p-6" style="" >
     <!--UPDATE START-->
      <table width="100%" border="0" class="tables">
     <tr>
      <td width="20%">
        
      </td>
      <td width="60%"><center><h1 class="text-primary">Innovice Selection<br/></h1></center></td>
       <td width="20%">
        </td>
      </tr>
    </table>
    <!--UPDATE END-->
    <br >
                <div class="vx-row mb-3">
                <div class="vx-col sm:w-1/6 " >
                  <span>Filter By</span>
                </div>
                <div class="vx-col sm:w-1/5" >
                  <vs-select v-model="city" class="w-full select-large" >
                  <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
                  </vs-select>
                </div> 
                </div>
<br>
      <div align="right" style="padding-top: 5px">
      <div class="vx-col sm:w-1/16 ">
                <center>
                <vs-button  color="primary"  size="medium" type="filled" style="!">Select All</vs-button>&nbsp;
                 <vs-button  color="primary" size="medium" type="filled" style="!">Unselect All</vs-button>&nbsp;
                  <vs-button  color="primary" size="medium" type="filled" style="!">Complex</vs-button>&nbsp;
                </center>
      </div>
      </div>
 <br><br>
<div  style="overflow-x:auto;">  
<table id="customers" >
  <tr >
    <th class="bg-primary">Tick</th>
    <th class="bg-primary">Date</th>
    <th class="bg-primary">Inv.No</th>
    <th class="bg-primary">Account Name</th>
    <th class="bg-primary">Contact</th>
     <th class="bg-primary">Address</th>
     <th class="bg-primary">Less</th>
    <th class="bg-primary">Qty</th>
    <th class="bg-primary">Value</th>
    <th class="bg-primary">Price</th>
    <th class="bg-primary">Delete</th>
  </tr>
  <tr v-for="(Innovice, k) in Inno_select" :key="k">  
    <td scope="row">
      
        <vs-checkbox class="w-full"  size="small" v-model="Innovice.tick" v-on:keyup.enter="addNewRowEnterkey(k,Innovice)" />
    </td>
    <div class="vx-col sm:w-1/6 w-full">
           <flat-pickr  v-model="date"  style="margin:2px;;width:100px; height:25px;"  placeholder="Select Date" />
    </div>
    <td>
      <vs-input class="w-full"  size="small" v-model="Innovice.invno" @keypress="onlyNumber" @change="totaladd(Innovice)" dir="rtl"   v-on:keyup.enter="addNewRowEnterkey(k,Innovice)"/>
    </td>
    <td><vs-input class="w-full" size="small" v-model="Innovice.accountname"  @change="totaladd(Innovice)"  v-on:keyup.enter="addNewRowEnterkey(k,Innovice)"/></td>
    <td><vs-input class="w-full" size="small" v-model="Innovice.contact" @change="totaladd(Innovice)" dir="rtl" @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,Innovice)"/></td>
    <td><vs-input class="w-full" size="small" v-model="Innovice.address"  dir="rtl"  v-on:keyup.enter="addNewRowEnterkey(k,Innovice)"/></td>
    <td><vs-input class="w-full" size="small" v-model="Innovice.less" dir="rtl" @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,Innovice)"/></td>
    <td><vs-input class="w-full" size="small" v-model="Innovice.qty"  dir="rtl" @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,Innovice)"/></td>
     <td><vs-input class="w-full" size="small" v-model="Innovice.Value"  dir="rtl" @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,Innovice)"/></td>
      <td><vs-input class="w-full" size="small" v-model="Innovice.price"  dir="rtl" @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,Innovice)"/></td>
     <td align="center"><vs-button size="small" icon-pack="feather" icon="icon-trash" color="danger" style="margin:3px;"  @click="deleteRow(k, Innovice)"></vs-button></td>
  </tr>
  </table>
</div>
<br/>
<div id="example">
      <vs-button class="button" size="small" @click="addNewRow();addNotify()" ><i class="fa fa-plus"></i></vs-button>
     &nbsp;
      <vs-button class="button" size="small"  @click="pop"><i class="fa fa-minus"></i></vs-button>
          &nbsp;
        <vs-button class="button" size="small" @click="saveInvoice">show all data</vs-button>
    </div> <i class="far fa-trash-alt" @click="deleteRow(k, Innovice)"></i>
<br/>
<table border="0" width="100%" class="tables" >
  <tr>
      
      <td  class="overlap" >
        <vs-input class="w-full" size="small" v-model="input1" />
      </td>
      <td  class="overlap" >
        <vs-input class="w-full" size="small" v-model="input2" />
      </td>
      <td  class="overlap" >
        <vs-input class="w-full" size="small" v-model="input3" />
      </td>
      <td  class="overlap" >
        <vs-input class="w-full" size="small" v-model="input4" />
      </td>
      <td  class="overlap">
        <vs-input class="w-full" size="small" v-model="input5" />
      </td>
      <td  class="overlap" align="right">CD@</td>
      <td  class="overlap" >
        <vs-input class="w-full" size="small" v-model="input6" />
      </td>
      
  </tr>
 </table>
 <div align="right" style="padding-top: 20px">
        <br>

      <div class="left" align="center">
        <br>
         <vs-button  color="primary" type="filled" style="!">Report</vs-button>&nbsp;
          <vs-button  color="primary" type="filled" style="!">Exit</vs-button>&nbsp;
           <vs-button  color="primary" type="filled" style="!">Update</vs-button>&nbsp;
      </div>
      </div>
</div>    
</template>
<script>
import  flatPickr  from 'vue-flatpickr-component';
import  'flatpickr/dist/flatpickr.css';
export default {
  data() {
        return {
            date:null,
            totalcount:0,
            input1:'',
            input2:'',
            input3:'',
            input4:'',
            input5:'',
            input6:'',
            Inno_select: [{
            tick:'',
            date:'',
            invno:'',
            accountname: '',
            contact: '',
            address: '',
            less: '',
            qty: '',
            Value: '',
            price: '',
            }]
        } 
    },
    components:{
      flatPickr
    },
    methods:{
          addNewRow(){
              this.Inno_select.push({
              tick:'',
              date:'',
              invno:'',
              accountname: '',
              contact: '',
              address: '',
              less: '',
              qty: '',
              Value: '',
              price: '',
              });
          },
         addNewRowEnterkey(index, bankVoucher) {
               var idx = this.Inno_select.indexOf(bankVoucher);
                 var len = this.Inno_select.length;
            console.log(idx,index);
            if (len-1==index) {
                this.Inno_select.push({
                tick:'',
                date:'',
                invno:'',
                accountname: '',
                contact: '',
                address: '',
                less: '',
                qty: '',
                Value: '',
                price: '',
                });
                     this.addNotify();
            }
        },
        deleteNotify(){
            this.$vs.notify({
              text: 'Row is deleted',
              color: "danger",
              iconPack: 'feather',
              icon:'icon-trash'
             })
      },
       addNotify(){
            this.$vs.notify({
              text: 'Row is Added',
              color: "primary",
              iconPack: 'feather',
              icon:'icon-plus'
             })
      },
        deleteRow(index, bankVoucher) {
            var idx = this.Inno_select.indexOf(bankVoucher);
            console.log(idx, index);
            if (idx > -1) {
                this.Inno_select.splice(idx, 1);
            }
            this.deleteNotify();
        },
        pop(){
           this.Inno_select.pop({         
            tick:'',
            date:'',
            invno:'',
            accountname: '',
            contact: '',
            address: '',
            less: '',
            qty: '',
            Value: '',
            price: '',
            });
            this.deleteNotify();
        },
         saveInvoice() {
            alert(JSON.stringify(this.Inno_select));
        },
        totaladd(bankVoucher){
             var total = parseFloat(bankVoucher.payment) * parseFloat(bankVoucher.discount);
           this.totalcount=total;
            this.calculateTotal(); 
        },  
          deletec(){
              this.Inno_select.pop({       
              tick:'',
              date:'',
              invno:'',
              accountname: '',
              contact: '',
              address: '',
              less: '',
              qty: '',
              Value: '',
              price: '',
            });
          },
         onlyNumber($event) {    
                let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
                if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) { // 46 is dot
                  return   $event.preventDefault();
                }
                else return null;           
          }
    },
    created() {
      for(var i=0;i<4;i++){
         this.addNewRow();
      }
    },
    computed: {
        now: function () {  
          var today = new Date();
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
          return date;
        },
        currentday: function(){
           var today = new Date();
           var weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var  currenday = weekday[today.getDay()];
            return currenday;
        }
    }
}
</script>












