<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;  
}
 #customers th {
  border: 1px solid #ddd; 
}
#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}
</style>
<template >

     <div class="vx-card p-6" style="" >
     <!--UPDATE START-->
      <table width="100%" border="0" class="tables">
     <tr>
      <td width="25%">
        
      </td>
       <td width="50%"><center><h1 class="text-primary">Ledger Account<br/></h1></center></td>
       <td width="25%"  align="right">  
      </td>
      </tr>
    </table>
    <!--UPDATE END-->
    <br>

    <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6 " >
          <span>Filter</span>
        </div>
        <div class="vx-col sm:w-1/10" >
          <vs-select v-model="filter" class="w-full select-large" size="small" >
          <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
          </vs-select>
      </div>
    </div>
    
<div  style="overflow-x:auto;">  
<table id="customers" >
  <tr >
    <th class="bg-primary">Account Name</th>
    <th class="bg-primary">City Name</th>
    <th class="bg-primary">Phone No</th>
    <th class="bg-primary">PAN/RC</th>
    <th class="bg-primary">GSTIN</th>
    <th class="bg-primary">Delete</th>
  </tr>
  <tr v-for="(ledger, k) in led_acc" :key="k">  
    <td scope="row">
        <vs-input class="w-full" size="small" v-model="ledger.accountname" v-on:keyup.enter="addNewRowEnterkey(k,ledger)" />
    </td>
    <td>
      <vs-input class="w-full" size="small"  v-model="ledger.cityname" @change="totaladd(ledger)"   v-on:keyup.enter="addNewRowEnterkey(k,ledger)" />
    </td>
    <td>
      <vs-input class="w-full"  size="small" v-model="ledger.phoneno" @change="totaladd(ledger)" dir="rtl" @keypress="onlyNumber"  v-on:keyup.enter="addNewRowEnterkey(k,ledger)"/>
    </td>
    <td><vs-input class="w-full" size="small" v-model="ledger.pan"  @change="totaladd(ledger)"  v-on:keyup.enter="addNewRowEnterkey(k,ledger)"/></td>
    <td><vs-input class="w-full" size="small" v-model="ledger.gstin" @change="totaladd(ledger)" dir="rtl" @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,ledger)"/></td>
    
     <td align="center"><vs-button size="small" icon-pack="feather" icon="icon-trash" color="danger" style="margin:3px;"  @click="deleteRow(k, ledger)"></vs-button></td>
  </tr>
  </table>
</div>
<br/>
<div id="example">
      <vs-button class="button" size="small" @click="addNewRow();addNotify()" ><i class="fa fa-plus"></i></vs-button>
     &nbsp;
      <vs-button class="button" size="small"  @click="pop"><i class="fa fa-minus"></i></vs-button>
          &nbsp;
        <vs-button class="button" size="small" @click="saveInvoice">show all data</vs-button>
    </div> <i class="far fa-trash-alt" @click="deleteRow(k, Innovice)"></i>
<br/>
<br>
<td></td>
<center>
 <div class="vx-row mb-3" align="center">
      <div class="vx-col sm:w-1/7" style="padding-left:100px"  >
        <vs-select v-model="search" class="w-full " style="margin:1px">
        <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
        </vs-select>
      </div> 
    <div class="vx-col sm:w-1/5 " style="padding-left:100px"  >
          <span >Search</span>
    </div>
    <div class="vx-col sm:w-1/10" style="margin:1px" >
      <vs-input class="w-full " size="small" style="width:175px; height:50px;" v-model="input1" />
      </div>
    <td></td>
 </div>
 </center>
 <div align="right" style="padding-top: 20px">
        <br>

      <div class="left" align="center">
        <br>
        <vs-button  color="primary" type="filled">Selection</vs-button>
        &nbsp;
        <vs-button  color="primary" type="filled" style="!">Modify</vs-button>&nbsp;
        <vs-button  color="primary" type="filled" style="!">Remarked</vs-button>&nbsp;
         <vs-button  color="primary" type="filled" style="!">Select</vs-button>&nbsp;
          <vs-button  color="primary" type="filled" style="!">Group</vs-button>&nbsp;
           <vs-button  color="primary" type="filled" style="!">Exit</vs-button>&nbsp;
      </div>
      </div>
</div>    
</template>
<script>
import  flatPickr  from 'vue-flatpickr-component';
import  'flatpickr/dist/flatpickr.css';
export default {
  data() {
        return {
            date:null,
            totalcount:0,
            Vouchno:'',
            bank:'',
            input1:'',
            led_acc: [{
            accountname: '',
            cityname: '',
            phoneno: '',
            pan: '',
            gstin: '',
            
            }]
        } 
    },
    components:{
      flatPickr
    },
    methods:{
          addNewRow(){
              this.led_acc.push({
              accountname: '',
              cityname: '',
              phoneno: '',
              pan: '',
              gstin: '',
              });
          },
         addNewRowEnterkey(index, ledger) {
               var idx = this.led_acc.indexOf(ledger);
                 var len = this.led_acc.length;
            console.log(idx,index);
            if (len-1==index) {
                this.led_acc.push({
                accountname: '',
                cityname: '',
                phoneno: '',
                pan: '',
                gstin: '',
                });
                     this.addNotify();
            }
        },
        deleteNotify(){
            this.$vs.notify({
              text: 'Row is deleted',
              color: "danger",
              iconPack: 'feather',
              icon:'icon-trash'
             })
      },
       addNotify(){
            this.$vs.notify({
              text: 'Row is Added',
              color: "primary",
              iconPack: 'feather',
              icon:'icon-plus'
             })
      },
        deleteRow(index, ledger) {
            var idx = this.led_acc.indexOf(ledger);
            console.log(idx, index);
            if (idx > -1) {
                this.led_acc.splice(idx, 1);
            }
            this.deleteNotify();
        },
        pop(){
           this.led_acc.pop({         
              accountname: '',
              cityname: '',
              phoneno: '',
              pan: '',
              gstin: '',
            });
            this.deleteNotify();
        },
         saveInvoice() {
            alert(JSON.stringify(this.led_acc));
        },
        totaladd(ledger){
             var total = parseFloat(ledger.payment) * parseFloat(ledger.discount);
           this.totalcount=total;
            this.calculateTotal(); 
        },  
          deletec(){
              this.led_acc.pop({       
              accountname: '',
              cityname: '',
              phoneno: '',
              pan: '',
              gstin: '',
            });
          },
         onlyNumber($event) {    
                let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
                if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) { // 46 is dot
                  return   $event.preventDefault();
                }
                else return null;           
          }
    },
    created() {
      for(var i=0;i<4;i++){
         this.addNewRow();
      }
    },
    computed: {
        now: function () {  
          var today = new Date();
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
          return date;
        },
        currentday: function(){
           var today = new Date();
           var weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var  currenday = weekday[today.getDay()];
            return currenday;
        }
    }
}
</script>




















