<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;  
}
 #customers th {
  border: 1px solid #ddd; 
}
#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}

 .tables 
{
    table-layout:fixed;
    width:100%;
    
}



@media screen and (min-width: 601px) {
  div.example {
    font-size: 15px;
    background-color:white; 
    padding: 55px;
    
    border-color: #7367f0;
     border-top-style: solid;
     border-bottom-style: solid;
  }
}

@media screen and (max-width: 600px) {
  div.example {
    font-size: 10px;
    background-color:white; 
    padding: 10px;
    
    border-color: #7367f0;
    border-top-style: solid;
    border-bottom-style: solid;
  }
}
</style>

<template>

    <div class="vx-card p-6" style="" >
     <!--UPDATE START-->
      <table width="100%" border="0" class="tables">
         <tr>
            <td width="25%">   
            </td>
            <td width="50%"><center><h1><font color="#7367f0">Company Reports</font><br><h4><font color="blue">Sale</font></h4></h1></center></td>
       <td width="25%"  align="right">  
          </td>
          </tr>
</table>
<br>
<table width="100%" border="0" class="tables"  align="center">
    <tr>
        <td style="width:10%" >
          <div class="vx-col sm:w-1/6 " >
                  <span align="center ">From</span>
                </div>
        </td>
        <td style="width:30%">
            <flat-pickr   v-model="date" size="small" style="width:px;"  placeholder="choose Date" />
        </td>
        <td style="width:10%">
          <div class="vx-col sm:w-1/6 " >
                  <span align=" ">Upto</span>
                </div>
        </td>
        <td style="width:20%">
            <flat-pickr   v-model="date" size="small" style="width:px;"  placeholder="choose Date" />
        </td>
    </tr><br>
</table>
<div align="right" style="padding-top: 5px">
      <div class="mid" >
                <center>
                <vs-button  color="primary" type="filled" style="!">Select Accounts</vs-button>&nbsp;
                 <vs-button  color="primary" type="filled" style="!">Select Product</vs-button>&nbsp;
                </center>
      </div>
      </div>

<br><br><br>
<table width="100%" border="0" class="tables"  align="center">
    <tr>
        <td></td>
        <td  id="overlap" align="center"><font color="#7367f0">Account options</font></td>
    </tr>
    <tr>
        <td id="overlap">
        City Name
        </td>
        <td id="overlap">
            <vs-input class="w-full" size="small" v-model="input1"/>
        </td>
   
        <td id="overlap" align="center">
          State
        </td>
        <td id="overlap">
            <vs-input class="w-full" size="small" v-model="input2" />
        </td>
    </tr><br>
    <tr>
        <td id="overlap">
        Agent
        </td>
        <td id="overlap">
            <vs-input class="w-full" size="small" v-model="input3"/>
        </td>
        <td id="overlap"></td>
        <td class="overlap"> 
            <vs-select v-model="qty" class="w-full  sm:w-1/10" style="width:30px" >
              <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
            </vs-select>
        </td>
</tr>
</table><br>
<div align="right" style="padding-top: 5px">
  <div class="mid" >
        <br>
                <center>
                <vs-button  color="primary" type="filled" style="!">Print</vs-button>&nbsp;
                 <vs-button  color="primary" type="filled" style="!">Exit</vs-button>&nbsp;
                </center>
      </div>
      </div>


</div>
</template>
<script>
import  flatPickr  from 'vue-flatpickr-component';
import  'flatpickr/dist/flatpickr.css';
export default {
  data() {
        return {
            date:null,
            input1:'',
            input2:'',
            input3:'',
        } 
    },
    components:{
      flatPickr
    },
    computed: {
        now: function () {  
          var today = new Date();
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
          return date;
        },
        currentday: function(){
           var today = new Date();
           var weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var  currenday = weekday[today.getDay()];
            return currenday;
        }
    }
}
</script>














