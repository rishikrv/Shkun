<style>
 .tables 
{
    table-layout:fixed;
    width:100%; 
}
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;  
}
 #customers th {
  border: 1px solid #ddd; 
}
#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}
</style>
<template>

    <div class="vx-card p-6" style="" >
     <!--UPDATE START-->
      <table width="100%" border="0" class="tables">
     <tr>
      
       <td width="50%"><center><h1 class="text-primary">Passbook Feeding<br/><h4><font color="grey">View</font></h4></h1></center></td>
      
      </tr>
        <br/>
      </table>         
    <!--UPDATE END-->
  
     <div class="vx-row mb-3" id="tables">
        <div class="vx-col sm:w-1/6 " >
          <span align="center ">Date </span>
        </div>
            <!--Used for date picking -->
        <div class="vx-col sm:w-1/6 w-full">
           <flat-pickr  v-model="date" size="small" style="width:175px; height:25px;"  placeholder="choose Date" />
        </div>
        
      </div>
        <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6 " >
          <span>Passbook No</span>
        </div>
        <div class="vx-col sm:w-1/5">
        <vs-input class="w-full" size="small" v-model="input1"  />    
            </div>
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6 " >
          <span align="center ">From </span>
        </div>
            <!--Used for date picking -->
        <div class="vx-col sm:w-1/6 w-full">
           <flat-pickr  v-model="date" size="small" style="width:175px; height:25px;"  placeholder="choose Date" />
        </div>
        
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6 " >
          <span align="center ">Upto </span>
        </div>
            <!--Used for date picking -->
        <div class="vx-col sm:w-1/6 w-full">
           <flat-pickr  v-model="date" size="small" style="width:175px; height:25px;"  placeholder="choose Date" />
        </div>
        
      </div>
      <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6 " >
          <span>Intt.@</span>
        </div>
        <div class="vx-col sm:w-1/5">
           <vs-input class="w-full"  v-model="input2" size="small" />
        </div>
      </div>
<br/>
<table align="center">
  <tr><td width="50%"></td>
  <td >
  <vs-button  color="primary" type="filled" style="!">Ok</vs-button>  
  </td>
  <td>
  <vs-button  color="primary" type="filled" style="!">Delete</vs-button>  
  </td>
  <td>
  <vs-button  color="primary" type="filled" style="!">Cancel</vs-button>
  </td>
  </tr>
</table>
<br>
<div  style="overflow-x:auto;">  
<table id="customers" >
  <tr >
    <th class="bg-primary">Date</th>
    <th class="bg-primary">Balance</th>
   
    <th class="bg-primary">Delete</th>
  </tr>
  <tr v-for="(pass, k) in pass_bk" :key="k">  
    <td scope="row">
        <vs-input class="w-full" size="small" v-model="pass.date" v-on:keyup.enter="addNewRowEnterkey(k,pass)" />
    </td>
    <td>
      <vs-input class="w-full" size="small"  v-model="pass.balance" @change="totaladd(pass)"  @keypress="onlyNumber" v-on:keyup.enter="addNewRowEnterkey(k,pass)" />
    </td>
     <td align="center"><vs-button size="small" icon-pack="feather" icon="icon-trash" color="danger" style="margin:3px;"  @click="deleteRow(k, pass)"></vs-button></td>
  </tr>
  </table>
</div>
<br/>
<div id="example">
      <vs-button class="button" size="small" @click="addNewRow();addNotify()" ><i class="fa fa-plus"></i></vs-button>
     &nbsp;
      <vs-button class="button" size="small"  @click="pop"><i class="fa fa-minus"></i></vs-button>
          &nbsp;
        <vs-button class="button" size="small" @click="saveInvoice">show all data</vs-button>
    </div> <i class="far fa-trash-alt" @click="deleteRow(k, pass)"></i>
<br/>
<div style="overflow-x:auto;"  width="100%">  
      <table  border="0" width="100%">
        <tr>
          <td class="hiden" width="13%"></td>
          <td><vs-input class="w-full" size="small" v-model="totalcount" /></td>
          <td><vs-input class="w-full" size="small" v-model="input3" dir="rtl" @keypress="onlyNumber" /> </td>
          <td><vs-input class="w-full" size="small" v-model="input4" dir="rtl" @keypress="onlyNumber" /></td>
          <td><vs-input class="w-full" size="small" v-model="input5" dir="rtl" @keypress="onlyNumber" /></td>
        </tr> 
      </table>
    </div>
<div align="right" style="padding-top: 10px">
        <br>
      <div class="right" align="right">
        <br>
         <vs-button class="button"  @click="print">Print</vs-button>
        &nbsp;
         <vs-button class="button"  @click="submit">Submit</vs-button>

      </div>
    </div>    
    </div>
</template>
<script>
import  flatPickr  from 'vue-flatpickr-component';
import  'flatpickr/dist/flatpickr.css';
export default {
  data() {
        return {
            date:null,
            totalcount:0,
            Vouchno:'',
            bank:'',
            input1:'',
            input2:'',
            input3:'',
            input4:'',
            input5:'',
            pass_bk: [{
            date: '',
            balance: '',
           
            }]
        } 
    },
    components:{
      flatPickr
    },
    methods:{
          addNewRow(){
              this.pass_bk.push({
              date: '',
              balance: '',
            });
          },
         addNewRowEnterkey(index, bankVoucher) {
               var idx = this.pass_bk.indexOf(bankVoucher);
                 var len = this.pass_bk.length;
            console.log(idx,index);
            if (len-1==index) {
                this.pass_bk.push({
                 date: '',
            balance: '',
                });
                     this.addNotify();
            }
        },
        deleteNotify(){
            this.$vs.notify({
              text: 'Row is deleted',
              color: "danger",
              iconPack: 'feather',
              icon:'icon-trash'
             })
      },
       addNotify(){
            this.$vs.notify({
              text: 'Row is Added',
              color: "primary",
              iconPack: 'feather',
              icon:'icon-plus'
             })
      },
        deleteRow(index, bankVoucher) {
            var idx = this.pass_bk.indexOf(bankVoucher);
            console.log(idx, index);
            if (idx > -1) {
                this.pass_bk.splice(idx, 1);
            }
            this.deleteNotify();
        },
        pop(){
           this.pass_bk.pop({         
               date: '',
            balance: '',
            });
            this.deleteNotify();
        },
         saveInvoice() {
            alert(JSON.stringify(this.pass_bk));
        },
        totaladd(bankVoucher){
             var total = parseFloat(bankVoucher.payment) * parseFloat(bankVoucher.discount);
           this.totalcount=total;
            this.calculateTotal(); 
        },  
          deletec(){
              this.pass_bk.pop({       
               date: '',
            balance: '',
            });
          },
         onlyNumber($event) {    
                let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
                if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) { // 46 is dot
                  return   $event.preventDefault();
                }
                else return null;           
          }
    },
    created() {
      for(var i=0;i<4;i++){
         this.addNewRow();
      }
    },
    computed: {
        now: function () {  
          var today = new Date();
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
          return date;
        },
        currentday: function(){
           var today = new Date();
           var weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var  currenday = weekday[today.getDay()];
            return currenday;
        }
    }
}
</script>













