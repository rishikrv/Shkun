<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;  
}
 #customers th {
  border: 1px solid #ddd; 
}
#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}

 .tables 
{
    table-layout:fixed;
    width:100%;
    
}



@media screen and (min-width: 601px) {
  div.example {
    font-size: 15px;
    background-color:white; 
    padding: 55px;
    
    border-color: #7367f0;
     border-top-style: solid;
     border-bottom-style: solid;
  }
}

@media screen and (max-width: 600px) {
  div.example {
    font-size: 10px;
    background-color:white; 
    padding: 10px;
    
    border-color: #7367f0;
    border-top-style: solid;
    border-bottom-style: solid;
  }
}
</style>
<template>

    <div class="vx-card p-6" style="" >
     <!--UPDATE START-->
      <table width="100%" border="0" class="tables">
         <tr>
           
            <td width="10%">   
            </td>
            <td width="50%"><center><h1><font color="#7367f0">TDS Form 26<br></font></h1></center></td>
            <td width="20%"  align="right">
       
          </td>
          </tr>
</table>
<br>
<br>
<table width="100%" border="0" class="tables"  align="">
<tr>
        <td id="overlap">Type</td>
        <td class="overlap"> 
            <vs-select v-model="Values" class="w-full  sm:w-1/16" style="width:90px" >
                  <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
            </vs-select>
        </td>
</tr>
<br>
<tr>
        <td id="overlap">
            Issue Date 
            </td>
        <td id="overlap">
            <flat-pickr  v-model="date" size="small" style="width:195px; height:25px;"  placeholder="choose Date" />
        </td>
        <td width="30%" id="overlap" align="center">
            TDS@
        </td>
        <td id="overlap">
            <vs-input  class="w-full"  size="small" v-model="input1"/>
        </td>
        <td></td>
    </tr><br>
    <tr>
        <td id="overlap" >
            BSR Code
        </td>
        <td id="overlap">
            <vs-input class="w-full" size="small" v-model="input2" />
        </td>
    </tr><br>
    <tr>
        <td id="overlap">
            Bank Name
        </td>
        <td id="overlap">
            <vs-input class="w-full" size="small" v-model="input3" />
        </td>
    </tr><br>
    <tr>
        <td id="overlap">
            Period From
        </td>
        <td id="overlap">
            <flat-pickr  v-model="date" size="small" style="width:195px; height:25px;"  placeholder="choose Date" />
        </td>
        <td width="30%" id="overlap" align="center">
            To
        </td>
        <td id="overlap">
            <flat-pickr  v-model="date" size="small" style="width:195px; height:25px;"  placeholder="choose Date" />
        </td>
    </tr><br>
    <tr>
        <td id="overlap" >
            1st Qtr Rec No.
        </td>
        <td id="overlap">
            <vs-input class="w-full" size="small" v-model="input4" />
        </td>
    
    
        <td id="overlap" align="center">
            2nd Qtr Rec No.
        </td>
        <td id="overlap">
            <vs-input class="w-full" size="small" v-model="input5" />
        </td>
    </tr><br>
    <tr>
        <td id="overlap" >
            3rd Qtr Rec No.
        </td>
        <td id="overlap">
            <vs-input class="w-full" size="small" v-model="input6" />
        </td>
        <td id="overlap" align="center">
            4th Qtr Rec No.
        </td>
        <td id="overlap">
            <vs-input class="w-full" size="small" v-model="input7" />
        </td>
    </tr><br>
    <tr>
    <td width="20%" id="overlap" align="">
           A/c
        </td>
        <td id="overlap">
            <vs-input class="w-full" size="small" v-model="input8" />
        </td> <td></td>  <td></td>
</tr>
<tr>
<td></td>    <td width="200%" id="overlap" align="">

    <vs-textarea style="margin:5px; width:180px" v-model="textarea" />

    </td>
</tr>
</table>
    <div align="right" style="padding-top: 5px">
    <div class="mid" align="">
        <br>&nbsp;&nbsp;&nbsp;&nbsp;
                <center><vs-button  color="primary" type="filled">Edit</vs-button>&nbsp;
                <vs-button  color="primary" type="filled" style="!">Export</vs-button>&nbsp;
                <vs-button  color="primary" type="filled" style="!">Print</vs-button>&nbsp;
                 <vs-button  color="primary" type="filled" style="!">Deposit</vs-button>&nbsp;
                </center>
    </div>
    </div>

</div>
</template>
<script>
import  flatPickr  from 'vue-flatpickr-component';
import  'flatpickr/dist/flatpickr.css';
export default {
  data() {
        return {
            date:null,
            input1:'',
            input2:'',
            input4:'',
            input5:'',
            input6:'',
            input7:'',
            input8:'',
            
        } 
    },
    components:{
      flatPickr
    },
    computed: {
        now: function () {  
          var today = new Date();
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
          return date;
        },
        currentday: function(){
           var today = new Date();
           var weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var  currenday = weekday[today.getDay()];
            return currenday;
        }
    }
}
</script>














