<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;  
}
 #customers th {
  border: 1px solid #ddd; 
}
#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}
@media screen and (min-width: 601px) {
  div.example {
    font-size: 15px;
    background-color:white; 
    padding: 55px;
    
    border-color: #7367f0;
     border-top-style: solid;
     border-bottom-style: solid;
  }
}

@media screen and (max-width: 600px) {
  div.example {
    font-size: 10px;
    background-color:white; 
    padding: 10px;
    
    border-color: #7367f0;
    border-top-style: solid;
    border-bottom-style: solid;
  }
  
}

.btns {
   width: 100%;
   min-width: 10px;  
   max-width: 300px; 
}
</style>
<template >

    <div class="vx-card p-6" style=""  >
      <center>
     <!--UPDATE START-->
    <table width="100%" border="0" class="tables">
        <tr>
          
       <td width="100%"><center><h1 class="text-primary">Pricing Options<br/></h1></center></td>
        </tr>
    </table>
        <br>    
    <div class="vx-row mb-3">
      <div class="vx-col sm:w-1/6 " >
      <span>A/c From</span>
      </div>
      <div class="vx-col sm:w-1/5" >
        <vs-select v-model="city" class="w-full select-large" >
        <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
        </vs-select>
      </div> 
    </div><br>
  <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6 " >
          <span> Period From </span>
        </div>
            <!--Used for date picking -->
        <div class="vx-col sm:w-1/6 w-full">
           <flat-pickr  v-model="date" size="small" style="width:180px; height:25px;"  placeholder="choose Date" />
        </div>
  </div>
  <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6 " >
          <span> Upto </span>
        </div>
            <!--Used for date picking -->
        <div class="vx-col sm:w-1/6 w-full">
           <flat-pickr  v-model="date" size="small" style="width:180px; height:25px;"  placeholder="choose Date" />
        </div>
        <td width="3%"></td>
        <td style="margin:2px" >
        <vs-radio v-model="radios1" vs-value="luis">Individual A/c</vs-radio>
        </td>
        
  </div>
  <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6 " >
          <span>Page Number</span>
        </div>
        <div class="vx-col sm:w-1/5">
           <vs-input v-model="input1" size="small" style="width:180px; height:24px;" placeholder="" />
        </div>
        <td width="%" ></td>
        <td >
        <vs-radio v-model="radios2" vs-value="luis">Next All A/c</vs-radio>
        </td>
  </div>
  <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6 " >
          <span>Group Name</span>
        </div>
        <div class="vx-col sm:w-1/5">
           <vs-input v-model="input2" size="small" style="width:180px; height:24px;" placeholder="" />
        </div>
        <td width="%"></td>
        <td >
        <vs-radio v-model="radios3" vs-value="luis">Selection</vs-radio>
        </td>
  </div>
  <div class="vx-row mb-3">
      <div class="vx-col sm:w-1/6 " >
      <span>Order By</span>
      </div>
      <div class="vx-col sm:w-1/5" >
        <vs-select v-model="city" class="w-full select-large" >
        <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
        </vs-select>
      </div> 
  </div>  
       <div align="right" style="padding-top: 20px">
        <br>
      <div class="left" align="center">
      <vs-button  color="primary" type="filled" style="!">Cancel</vs-button>&nbsp;
      <vs-button  color="primary" type="filled" style="!">Submit</vs-button>&nbsp;
    </div>
    </div>
      </center>
    </div>    
</template>
<script>
import  flatPickr  from 'vue-flatpickr-component';
import  'flatpickr/dist/flatpickr.css';
export default {
  data() {
        return {
            date:null,
            totalcount:0,
            input1:'',
            input2:'',
        } 
    },
    components:{
      flatPickr
    },
    computed: {
        now: function () {  
          var today = new Date();
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
          return date;
        },
        currentday: function(){
           var today = new Date();
           var weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var  currenday = weekday[today.getDay()];
            return currenday;
        }
    }
}
</script>






