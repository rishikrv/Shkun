<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;  
}
 #customers th {
  border: 1px solid #ddd; 
}
#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}

 .tables 
{
    table-layout:fixed;
    width:100%;
    
}



@media screen and (min-width: 601px) {
  div.example {
    font-size: 15px;
    background-color:white; 
    padding: 55px;
    
    border-color: #7367f0;
     border-top-style: solid;
     border-bottom-style: solid;
  }
}

@media screen and (max-width: 600px) {
  div.example {
    font-size: 10px;
    background-color:white; 
    padding: 10px;
    
    border-color: #7367f0;
    border-top-style: solid;
    border-bottom-style: solid;
  }
}
</style>
<template>

    <div class="vx-card p-6" style="" >
     <!--UPDATE START-->
<table width="100%" border="0" class="tables"  align="center">
<tr>
        <td align="center">A/c</td>
        <td class="overlap"> 
            <vs-select v-model="type" class="w-full  sm:w-1/10" style="width:30px" >
              <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
            </vs-select>
        </td>
</tr><br>
    <tr>
        <td  align="center" >
          <div class="vx-col sm:w-1/6 " >
                  <span align="center ">From</span>
                </div>
        </td>
        <td style="width:100px">
          <flat-pickr   v-model="date" size="small" style="width:250px;"  placeholder="choose Date" />

        </td>
        <td width="30%" id="overlap" align="center">
          <div class="vx-col sm:w-1/6 " >
                  <span align="center ">Upto</span>
                </div>
        </td>
        <td>
          <flat-pickr  v-model="date" size="small" style="width:250px;"  placeholder="choose Date" />
        </td>
    </tr><br>
    <tr>
        <td  align="center">
        Innovice No.
        </td>
        <td>
            <vs-input class="w-full" size="small" v-model="input1"/>
        </td>
   
        <td align="center">
         Innovice Dt.
        </td>
        <td>
          <flat-pickr  v-model="date" size="small" style="width:250px;"   placeholder="choose Date" />

        </td>
    </tr><br>
    <tr>
        <td  align="center">
        Vehicle No.
        </td>
        <td>
            <vs-input class="w-full" size="small" v-model="input2"/>
        </td>
        <td align="center">Filter</td>
        <td class="overlap"> 
            <vs-select v-model="filter" class="w-full  sm:w-1/10" style="width:30px" >
              <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
            </vs-select>
        </td>
    </tr>
</table><br>
        <div align="right" >
                <center>
                <vs-button  color="primary" type="filled" style="!">Print</vs-button>&nbsp;
                 <vs-button  color="primary" type="filled" style="!">Exit</vs-button>&nbsp;
                </center>

      </div>


</div>
</template>
<script>
import  flatPickr  from 'vue-flatpickr-component';
import  'flatpickr/dist/flatpickr.css';
export default {
  data() {
        return {
            date:null,
            input1:'',
            input2:'',
        } 
    },
    components:{
      flatPickr
    },
    computed: {
        now: function () {  
          var today = new Date();
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
          return date;
        },
        currentday: function(){
           var today = new Date();
           var weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var  currenday = weekday[today.getDay()];
            return currenday;
        }
    }
}
</script>







