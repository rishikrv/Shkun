<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;  
}
 #customers th {
  border: 1px solid #ddd; 
}
#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}

 .tables 
{
    table-layout:fixed;
    width:100%;
    
}



@media screen and (min-width: 601px) {
  div.example {
    font-size: 15px;
    background-color:white; 
    padding: 55px;
    
    border-color: #7367f0;
     border-top-style: solid;
     border-bottom-style: solid;
  }
}

@media screen and (max-width: 600px) {
  div.example {
    font-size: 10px;
    background-color:white; 
    padding: 10px;
    
    border-color: #7367f0;
    border-top-style: solid;
    border-bottom-style: solid;
  }
  
}
</style>
<template >
    <div class="vx-card p-6" style  > 
     <!--UPDATE START-->
    <table width="100%" border="0" class="tables">
         <tr>
           
            <td width="10%">   
            </td>
 <td width="50%"><center><h1 class="text-primary">Credit Note<br><h4><font color="grey">View</font></h4></h1></center></td>     
   <td width="25%"  ><h6>Edge on ledger</h6>
       <tr>
          <td>
              <vs-select v-model="Values" class="w-full select-large" >
                  <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
              </vs-select>
       
          </td>
          </tr>
          </td>
          </tr>
     
    </table>

         
    <!--UPDATE END-->
    <br>

               
                 <div class="vx-row mb-3">
                <div class="vx-col sm:w-1/6 " >
                  <span align="center ">Date </span>
                </div>
                    <!--Used for date picking -->
                <div class="vx-col sm:w-1/6 w-full">
                  <flat-pickr  v-model="date" size="small" style="width:175px; height:25px;"  placeholder="choose Date" />
                </div>
                 </div>
                
<div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6 " >
          <span>V. No</span>
        </div>
        <div class="vx-col sm:w-1/5">
          <vs-input class="w-full" size="small" v-model="input1"  />    
        </div>
</div>
<div class="vx-row mb-3">
  <div class="vx-col sm:w-1/6 " >
    <span>Credit</span>
  </div>
  <div class="vx-col sm:w-1/5">
    <vs-input class="w-full" size="small" v-model="input2"  />    
  </div>
  <div class="vx-col sm:w-1/6 " >
    <span>Debit</span>
  </div>
  <div class="vx-col sm:w-1/5">
    <vs-input class="w-full" size="small" v-model="input3"  />    
  </div>
  </div>
<div class="vx-row mb-3">
  <div class="vx-col sm:w-1/6 " >
    <span>Details</span>
  </div>
  <div>
    <vs-textarea style="margin:10px; width:180px" v-model="textarea" />
  </div>
</div>
<div class="vx-row mb-3">
  <div class="vx-col sm:w-1/6 " >
    <span>Qty</span>
  </div>
  <div class="vx-col sm:w-1/5">
    <vs-input class="w-full" size="small" v-model="input4"  />    
  </div>
  <div class="vx-col sm:w-1/6 " >
    <span>Amount</span>
  </div>
  <div class="vx-col sm:w-1/5">
    <vs-input class="w-full" size="small" v-model="input5"  />    
  </div>
  </div>
  <div class="vx-row mb-3">
        <div class="vx-col sm:w-1/6 " >
          <span>Rate</span>
        </div>
        <div class="vx-col sm:w-1/5">
          <vs-input class="w-full" size="small" v-model="input6"  />    
        </div>
</div>
<div align="right" style="padding-top: 20px">
        <br>

      <div class="left" align="center">
        <br>
        <vs-button  color="primary" type="filled">New</vs-button>
        &nbsp;
        <vs-button  color="primary" type="filled" style="!">Edit</vs-button>&nbsp;
        <vs-button  color="primary" type="filled" style="!">Save</vs-button>&nbsp;
         <vs-button  color="primary" type="filled" style="!">Delete</vs-button>&nbsp;
          <vs-button  color="primary" type="filled" style="!">Cancel</vs-button>&nbsp;
           <vs-button  color="primary" type="filled" style="!">Print</vs-button>&nbsp;
      </div>
      </div>

    </div>
  
</template>
<script>
import  flatPickr  from 'vue-flatpickr-component';
import  'flatpickr/dist/flatpickr.css';
export default {
  data() {
        return {
            date:null,
            input1:'',
            input2:'',
            input3:'',
            input4:'',
            input5:'',
            input6:'',
        } 
    },
    components:{
      flatPickr
    },
    computed: {
        now: function () {  
          var today = new Date();
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
          return date;
        },
        currentday: function(){
           var today = new Date();
           var weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var  currenday = weekday[today.getDay()];
            return currenday;
        }
    }
}
</script>










