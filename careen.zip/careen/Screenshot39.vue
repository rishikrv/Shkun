/* eslint-disable vue/valid-template-root */
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;  
}
 #customers th {
  border: 1px solid #ddd; 
}
#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #7367f0;
  color: white;
}

 .tables 
{
    table-layout:fixed;
    width:100%;
    
}



@media screen and (min-width: 601px) {
  div.example {
    font-size: 15px;
    background-color:white; 
    padding: 55px;
    
    border-color: #7367f0;
     border-top-style: solid;
     border-bottom-style: solid;
  }
}

@media screen and (max-width: 600px) {
  div.example {
    font-size: 10px;
    background-color:white; 
    padding: 10px;
    
    border-color: #7367f0;
    border-top-style: solid;
    border-bottom-style: solid;
  }
}
</style>
<template>

    <div class="vx-card p-6" style="" >
     <!--UPDATE START-->
      <table width="100%" border="0" class="tables">
         <tr>
          
            <td width="40%" align="center"><h1><font color="#7367f0"><u>PUNJAB POLLUTION REPORT ON IMPORTED MATERIAL</u></font></h1></td>
            
          </tr>
</table>
<br><br>
<table width="100%" border="0" class="tables"  align="center">
    <tr>
        <td id="overlap" align="center">
            <div class="vx-col sm:w-1/6 " >
                  <span align="center ">From</span>
                </div>
        </td>
        <td>
          <flat-pickr   v-model="date" size="small"  style="width:230px;" placeholder="choose Date" />
        </td>
        <td width="30%" id="overlap" align="center">
        <div class="vx-col sm:w-1/6 " >
                  <span align="center ">Upto</span>
                </div>
        </td>
        <td id="overlap">
          <flat-pickr   v-model="date" style="width:200px;" size="small"   placeholder="choose Date" />
        </td>
    </tr><br>
    <tr>
        <td id="overlap"  align="center">Pur.Tx.Type</td>
        <td> 
            <vs-select v-model="type1" class="w-full sm:w-1/8"  >
              <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
            </vs-select>
        </td>
   
         <td id="overlap"  align="center">Sale.Tx.Type</td>
        <td> 
            <vs-select v-model="type2" class=" sm:w-1/8"  >
              <vs-select-item :key="index" :value="item.value" :text="item.text" v-for="(item,index) in cityOptions" class="w-full" />
            </vs-select>
        </td>
    </tr><br>
     <tr>
        <td width="30%" id="overlap" align="center">
            <div class="vx-col sm:w-1/6 " >
                  <span align="center ">A/c </span>
                </div>
            </td>
            <td id="overlap" >
          <vs-input class="w-full" size="small" v-model="input1"  />    
        </td>
        <td id="overlap" align="center">
            Exclude
        </td>
            <td></td>
    </tr>
    <tr>
    <td width="20%" id="overlap" align=""> 
        </td>
        <td> 
           <vs-textarea class="w-full" size="small" v-model="textarea" />
        </td>
       <table width="100%" border="0" class="tables"  align="center">
        <tr>
        <td  align="center" width="45%"> </td>
        
        <td  align="center" width="20%">        
            <vs-checkbox class="w-full" v-align="center"  size="small" v-model="checkbox1" vs-value="luis"></vs-checkbox><br>
            <vs-checkbox class="w-full" v-align=""  size="small" v-model="checkbox2" vs-value="luis"></vs-checkbox> 
        </td>
       <td  align="center" width="45%"></td></tr></table>
       <td></td>
    </tr>
    <tr>
    <td></td>
    <td>
        <vs-input class="w-full" size="small" v-model="input2" />
    </td>
    <td align="center"></td>
        
</tr>
</table>
<br>
        <div align="right" style="padding-top: 5px">
        <br>
      <div class="mid" >
                <center>
                <vs-button  color="primary" type="filled" style="!">Select Product</vs-button>&nbsp;
                <vs-button  color="primary" type="filled" style="!">Print</vs-button>&nbsp;
                 <vs-button  color="primary" type="filled" style="!">Exit</vs-button>&nbsp;
                </center>
      </div>
      </div>


</div>
</template>
<script>
import  flatPickr  from 'vue-flatpickr-component';
import  'flatpickr/dist/flatpickr.css';
export default {
  data() {
        return {
            date:null,
            input1:'',
            input2:'',
        } 
    },
    components:{
      flatPickr
    },
    computed: {
        now: function () {  
          var today = new Date();
          var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
          return date;
        },
        currentday: function(){
           var today = new Date();
           var weekday=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            var  currenday = weekday[today.getDay()];
            return currenday;
        }
    }
}
</script>














